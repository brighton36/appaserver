-- MySQL dump 10.13  Distrib 5.7.22, for Linux (x86_64)
--
-- Host: localhost    Database: template
-- ------------------------------------------------------
-- Server version	5.7.22-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `additional_drop_down_attribute`
--

DROP TABLE IF EXISTS `additional_drop_down_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `additional_drop_down_attribute` (
  `drop_down_folder` char(50) NOT NULL,
  `folder` char(35) NOT NULL,
  `attribute` char(60) NOT NULL,
  UNIQUE KEY `additional_drop_down_attribute` (`drop_down_folder`,`folder`,`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `additional_drop_down_attribute`
--

LOCK TABLES `additional_drop_down_attribute` WRITE;
/*!40000 ALTER TABLE `additional_drop_down_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `additional_drop_down_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `additional_user_drop_down_attribute`
--

DROP TABLE IF EXISTS `additional_user_drop_down_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `additional_user_drop_down_attribute` (
  `login_name` char(50) NOT NULL,
  `drop_down_folder` char(50) NOT NULL,
  `folder` char(35) NOT NULL,
  `attribute` char(60) NOT NULL,
  `prepend_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `additional_user_drop_down_attribute` (`login_name`,`drop_down_folder`,`folder`,`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `additional_user_drop_down_attribute`
--

LOCK TABLES `additional_user_drop_down_attribute` WRITE;
/*!40000 ALTER TABLE `additional_user_drop_down_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `additional_user_drop_down_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_sessions`
--

DROP TABLE IF EXISTS `appaserver_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appaserver_sessions` (
  `appaserver_session` char(10) NOT NULL,
  `login_name` char(50) DEFAULT NULL,
  `login_date` date DEFAULT NULL,
  `login_time` char(4) DEFAULT NULL,
  `last_access_date` date DEFAULT NULL,
  `last_access_time` char(4) DEFAULT NULL,
  `http_user_agent` char(80) DEFAULT NULL,
  `remote_ip_address` char(15) DEFAULT NULL,
  UNIQUE KEY `appaserver_sessions` (`appaserver_session`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_sessions`
--

LOCK TABLES `appaserver_sessions` WRITE;
/*!40000 ALTER TABLE `appaserver_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `appaserver_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appaserver_user`
--

DROP TABLE IF EXISTS `appaserver_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appaserver_user` (
  `login_name` char(50) NOT NULL,
  `person_full_name` char(30) DEFAULT NULL,
  `password` char(45) DEFAULT NULL,
  `user_date_format` char(15) DEFAULT NULL,
  UNIQUE KEY `appaserver_user` (`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appaserver_user`
--

LOCK TABLES `appaserver_user` WRITE;
/*!40000 ALTER TABLE `appaserver_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `appaserver_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `application_constants`
--

DROP TABLE IF EXISTS `application_constants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_constants` (
  `application_constant` char(80) NOT NULL,
  `application_constant_value` text,
  UNIQUE KEY `application_constants` (`application_constant`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_constants`
--

LOCK TABLES `application_constants` WRITE;
/*!40000 ALTER TABLE `application_constants` DISABLE KEYS */;
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('#color4','#ccefff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('easycharts_width','800');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('easycharts_height','500');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('#color3','#a6e2ff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('#color2','#8cdaff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('#color5','#e6f7ff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('#color1','#73d2ff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('color1','#B4CDCD');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('##color2','#94d6e7');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('##color3','#c6eff7');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('color2','#ffffff');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('google_map_key','AIzaSyCOV1GzhO9OVcL9t1_kX2TTuxRBuck8P84');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('cat_javascript_source','no');
INSERT INTO `application_constants` (`application_constant`, `application_constant_value`) VALUES ('utc_offset','-8');
/*!40000 ALTER TABLE `application_constants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute`
--

DROP TABLE IF EXISTS `attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribute` (
  `attribute` char(60) NOT NULL,
  `attribute_datatype` char(20) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `float_decimal_places` int(11) DEFAULT NULL,
  `hint_message` text,
  `post_change_javascript` char(50) DEFAULT NULL,
  `on_focus_javascript_function` char(255) DEFAULT NULL,
  `lookup_histogram_output_yn` char(1) DEFAULT NULL,
  `lookup_time_chart_output_yn` char(1) DEFAULT NULL,
  `appaserver_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `attribute` (`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute`
--

LOCK TABLES `attribute` WRITE;
/*!40000 ALTER TABLE `attribute` DISABLE KEYS */;
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('permission','text',10,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('attribute','text',60,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('attribute_datatype','text',20,0,'','','','n','n','y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('command_line','text',512,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('float_decimal_places','integer',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('display_order','integer',3,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('drop_down_multi_select_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('drop_down_prompt','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('drop_down_prompt_data','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('application','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('folder','text',35,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('folder_count_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('pair_1tom_order','integer',2,NULL,'Pairing two tables allows you%0D%0Ato insert into both at the%0D%0Asame time. Also, many tables%0D%0Acan be paired to a single%0D%0A\'one\' table, then when you%0D%0Ainsert into the \'one\' table,%0D%0Aall the multiple tables appear%0D%0Ain the edit screen%0D%0Asequentially for insertion.%0D%0AFOLDER is a good example of%0D%0Athe multiple inserts.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('form','text',6,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('hint_message','notepad',512,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('input_width','integer',5,0,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('insert_rows_number','integer',2,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('login_name','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('lookup_email_output_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('next_session_number','integer',5,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('notepad','notepad',4096,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('null','text',0,4,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('operation','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('output_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('password','password',45,0,'1) An empty password will prevent logging in. 2) Assign new users to password of \'changeit\'. 3) Reset forgotten passwords to \'changeit\'.',NULL,NULL,'n','n','y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('person_full_name','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('populate_drop_down_process','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('insert_operation','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('update_operation','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('primary_key_index','integer',3,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('process','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('process_set','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prompt','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('related_attribute','text',60,NULL,'It is required that all%0D%0Aforeign keys be the same name%0D%0Aas the corresponding primary%0D%0Akeys, except the last one. If%0D%0Athe last foreign key differs%0D%0Afrom the last primary key, set%0D%0Athis attribute to it. This is%0D%0Anecessary for recursive or%0D%0Amultiple relationships. For%0D%0Aexample, the table RELATION%0D%0Ahas two relationships to%0D%0AFOLDER.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('related_folder','text',35,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('role','text',25,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('appaserver_session','text',10,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('width','integer',5,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('application_title','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('relative_source_directory','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('next_reference_number','integer',8,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('background_color','text',7,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('omit_1tom_detail_yn','text',1,NULL,'If a related folder has too many rows to effectively appear on the detail button, then set this flag.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('relation_type_isa_yn','text',1,NULL,'Appaserver provides an \'isa\'%0D%0Arelation for a folder that \'is%0D%0Aa\' another folder. When one%0D%0Afolder \'is a\' another folder,%0D%0Athere must be a one-to-one%0D%0Arelationship between them, and%0D%0Athen the one folder inherits%0D%0Athe attributes of the other.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prompt_mto1_recursive_yn','text',1,NULL,'The prompt screen gives you a%0D%0Adrop down for each related%0D%0Afolder. However, it might be%0D%0Auseful to have the folder in%0D%0Athe drop down to display its%0D%0Arelated drop downs too.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('omit_insert_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('distill_directory','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('ghost_script_directory','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('upload_filename_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('last_access_date','date',11,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('last_access_time','time',4,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('grace_home_directory','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('execution_count','integer',8,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('grace_free_option_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('omit_insert_prompt_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('frameset_menu_horizontal_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('post_change_javascript','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('chart_email_command_line','text',255,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('preprompt_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prompt_display_bottom_yn','text',1,0,'If all the processes in a%0D%0Aprocess set are output%0D%0Aprocesses, then placing the%0D%0Aprocess selection at the%0D%0Abottom might be appropriate.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('html_help_file_anchor','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('javascript_filename','text',80,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('row_access_count','integer',6,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prepend_http_protocol_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('post_change_process','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('index_directory','text',50,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('copy_common_attributes_yn','text',1,NULL,'This flag is for a business application for when you want to copy a common attribute from the \'one\' folder to the \'many\' folder. An example would be to preserve the price of an item in INVENTORY sold to a CUSTOMER via an INVOICE.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('additional_unique_index_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('additional_index_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('ssl_support_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('max_drop_down_size','integer',5,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('automatic_preselection_yn','text',1,NULL,'When inserting new rows, you%0D%0Amight want to preselect only%0D%0Athose rows in the many folder%0D%0Athat join to the one folder.%0D%0AWhen this flag is set, the%0D%0Aedit screen appears like a%0D%0Aspreadsheet, allowing you to%0D%0Aeasily insert an entire block%0D%0Aof data at a time.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('override_row_restrictions_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('row_level_restriction','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('datatype_bar_graph_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('datatype_scale_graph_zero_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('grace_execution_directory','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('grace_output','text',15,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('lookup_histogram_output_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('lookup_time_chart_output_yn','text',1,NULL,'The folder must have a date as a primary key.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('tablespace','text',20,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('exclude_application_export_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('date_format','text',15,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('database_date_format','text',15,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('user_date_format','text',15,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('date_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('date_attribute','text',60,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('time_attribute','text',60,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('datatype_folder','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('lookup_required_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('appaserver_version','text',10,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('http_user_agent','text',80,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('process_generic_unit','text',15,NULL,'Where is the units attribute?',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('process_set_display','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('remote_ip_address','text',15,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('login_date','date',11,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('login_time','time',4,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('appaserver_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('max_query_rows_for_drop_downs','integer',4,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('application_constant','text',80,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('application_constant_value','text',256,0,NULL,NULL,NULL,'n','n','y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('insert_required_yn','text',1,0,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('optional_display','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('foreign_folder','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('lookup_before_drop_down_yn','text',1,0,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prompt_display_text','text',25,0,'By default, the prompt for the%0D%0Aprocess names is \'Process\'.%0D%0AHowever, many process sets are%0D%0Aoutput-only processes.%0D%0ATherefore, changing the prompt%0D%0Adisplay to \'Output Medium\' is%0D%0Adesirable.',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('join_1tom_each_row_yn','text',1,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('select_statement','notepad',4096,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('foreign_key_index','integer',3,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('subschema','text',30,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('process_group','text',20,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('upgrade_script','text',80,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('on_focus_javascript_function','text',255,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('value_attribute','text',60,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('value_folder','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('no_initial_capital_yn','text',1,0,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('drop_down_folder','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('prepend_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('populate_helper_process','text',40,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('omit_update_yn','text',1,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('data_directory','text',50,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('datatype_aggregation_sum_yn','text',1,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('select_statement_title','text',80,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('attribute_not_null','text',50,NULL,NULL,NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('preprompt_help_text','notepad',1024,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('omit_lookup_before_drop_down_yn','text',1,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('ajax_fill_drop_down_yn','text',1,0,'',NULL,NULL,NULL,NULL,'y');
INSERT INTO `attribute` (`attribute`, `attribute_datatype`, `width`, `float_decimal_places`, `hint_message`, `post_change_javascript`, `on_focus_javascript_function`, `lookup_histogram_output_yn`, `lookup_time_chart_output_yn`, `appaserver_yn`) VALUES ('foreign_attribute','text',60,NULL,NULL,NULL,NULL,NULL,NULL,'y');
/*!40000 ALTER TABLE `attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_datatype`
--

DROP TABLE IF EXISTS `attribute_datatype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribute_datatype` (
  `attribute_datatype` char(20) NOT NULL,
  UNIQUE KEY `attribute_datatype` (`attribute_datatype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_datatype`
--

LOCK TABLES `attribute_datatype` WRITE;
/*!40000 ALTER TABLE `attribute_datatype` DISABLE KEYS */;
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('current_date');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('current_date_time');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('current_time');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('date');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('date_time');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('float');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('hidden_text');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('http_filename');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('integer');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('notepad');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('password');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('reference_number');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('text');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('time');
INSERT INTO `attribute_datatype` (`attribute_datatype`) VALUES ('timestamp');
/*!40000 ALTER TABLE `attribute_datatype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_exclude`
--

DROP TABLE IF EXISTS `attribute_exclude`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `attribute_exclude` (
  `role` char(25) NOT NULL,
  `attribute` char(60) NOT NULL,
  `permission` char(10) NOT NULL,
  UNIQUE KEY `attribute_exclude` (`role`,`attribute`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_exclude`
--

LOCK TABLES `attribute_exclude` WRITE;
/*!40000 ALTER TABLE `attribute_exclude` DISABLE KEYS */;
/*!40000 ALTER TABLE `attribute_exclude` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `date_formats`
--

DROP TABLE IF EXISTS `date_formats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `date_formats` (
  `date_format` char(15) NOT NULL,
  UNIQUE KEY `date_formats` (`date_format`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `date_formats`
--

LOCK TABLES `date_formats` WRITE;
/*!40000 ALTER TABLE `date_formats` DISABLE KEYS */;
INSERT INTO `date_formats` (`date_format`) VALUES ('american');
INSERT INTO `date_formats` (`date_format`) VALUES ('international');
INSERT INTO `date_formats` (`date_format`) VALUES ('military');
/*!40000 ALTER TABLE `date_formats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drop_down_prompt`
--

DROP TABLE IF EXISTS `drop_down_prompt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drop_down_prompt` (
  `drop_down_prompt` char(50) NOT NULL,
  `hint_message` text,
  `optional_display` char(40) DEFAULT NULL,
  UNIQUE KEY `drop_down_prompt` (`drop_down_prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drop_down_prompt`
--

LOCK TABLES `drop_down_prompt` WRITE;
/*!40000 ALTER TABLE `drop_down_prompt` DISABLE KEYS */;
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('null','Necessary for outter joins to work',NULL);
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('output_medium',NULL,NULL);
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('predictivebooks_module',NULL,'module');
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('export_output',NULL,NULL);
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('export_application_export_output',NULL,'export_output');
INSERT INTO `drop_down_prompt` (`drop_down_prompt`, `hint_message`, `optional_display`) VALUES ('execute_select_statement_output_medium',NULL,'output_medium');
/*!40000 ALTER TABLE `drop_down_prompt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drop_down_prompt_data`
--

DROP TABLE IF EXISTS `drop_down_prompt_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drop_down_prompt_data` (
  `drop_down_prompt` char(50) NOT NULL,
  `drop_down_prompt_data` char(50) NOT NULL,
  `display_order` int(11) DEFAULT NULL,
  UNIQUE KEY `drop_down_prompt_data` (`drop_down_prompt`,`drop_down_prompt_data`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drop_down_prompt_data`
--

LOCK TABLES `drop_down_prompt_data` WRITE;
/*!40000 ALTER TABLE `drop_down_prompt_data` DISABLE KEYS */;
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('output_medium','table',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('output_medium','spreadsheet',3);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('predictivebooks_module','enterprise',4);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('predictivebooks_module','home',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_output','shell_script',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_output','gzip_file',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_application_export_output','shell_script',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_application_export_output','spreadsheet',3);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('export_application_export_output','gzip_file',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('execute_select_statement_output_medium','table',1);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('execute_select_statement_output_medium','spreadsheet',2);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('predictivebooks_module','nonprofit',3);
INSERT INTO `drop_down_prompt_data` (`drop_down_prompt`, `drop_down_prompt_data`, `display_order`) VALUES ('predictivebooks_module','rentalproperty',2);
/*!40000 ALTER TABLE `drop_down_prompt_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder`
--

DROP TABLE IF EXISTS `folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder` (
  `folder` char(35) NOT NULL,
  `form` char(6) DEFAULT NULL,
  `insert_rows_number` int(11) DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `lookup_email_output_yn` char(1) DEFAULT NULL,
  `notepad` text,
  `no_initial_capital_yn` char(1) DEFAULT NULL,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `post_change_process` char(40) DEFAULT NULL,
  `lookup_before_drop_down_yn` char(1) DEFAULT NULL,
  `exclude_application_export_yn` char(1) DEFAULT NULL,
  `appaserver_yn` char(1) DEFAULT NULL,
  `subschema` char(30) DEFAULT NULL,
  `data_directory` char(50) DEFAULT NULL,
  `index_directory` char(50) DEFAULT NULL,
  UNIQUE KEY `folder` (`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder`
--

LOCK TABLES `folder` WRITE;
/*!40000 ALTER TABLE `folder` DISABLE KEYS */;
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('appaserver_sessions','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('appaserver_user','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'n',NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('application','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('attribute','prompt',10,'attribute_list',NULL,NULL,NULL,NULL,'post_change_attribute( $row )',NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('attribute_datatype','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('attribute_exclude','prompt',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('drop_down_prompt','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('drop_down_prompt_data','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('folder','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('folder_attribute','prompt',20,NULL,NULL,NULL,NULL,NULL,'post_change_folder_attribute( $row )',NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('form','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('null','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('operation','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','operation',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('permissions','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_set','prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_set',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('prompt','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('relation','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role_appaserver_user','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role_folder','prompt',20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role_operation','prompt',20,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','operation',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role_process','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('role_process_set_member','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_set',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('row_level_restrictions','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('folder_row_level_restrictions','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('grace_output','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('date_formats','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_generic_value_folder','table',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_generic_output',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_generic_units','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_generic_output',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_generic_datatype_folder','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_generic_output',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_generic_output','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_generic_output',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('application_constants','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('javascript_files','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','javascript',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('javascript_folders','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','javascript',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('javascript_processes','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','javascript',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('javascript_process_sets','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','javascript',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_groups','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_parameter','prompt',5,NULL,'n','When inserting, you must explicitly set to null (or ignore) the primary keys that do not apply to a parameter -- folder, attribute, prompt, and drop down prompt.',NULL,NULL,NULL,NULL,NULL,NULL,'y','process',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('process_set_parameter','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','process_set',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('subschemas','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('upgrade_scripts','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('additional_user_drop_down_attribute','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('additional_drop_down_attribute','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('row_security_role_update','table',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('login_default_role','table',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','security',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('select_statement','prompt',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','application',NULL,NULL);
INSERT INTO `folder` (`folder`, `form`, `insert_rows_number`, `populate_drop_down_process`, `lookup_email_output_yn`, `notepad`, `no_initial_capital_yn`, `html_help_file_anchor`, `post_change_javascript`, `post_change_process`, `lookup_before_drop_down_yn`, `exclude_application_export_yn`, `appaserver_yn`, `subschema`, `data_directory`, `index_directory`) VALUES ('foreign_attribute','prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y','folder',NULL,NULL);
/*!40000 ALTER TABLE `folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_attribute`
--

DROP TABLE IF EXISTS `folder_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_attribute` (
  `folder` char(35) NOT NULL,
  `attribute` char(60) NOT NULL,
  `primary_key_index` int(11) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `omit_insert_prompt_yn` char(1) DEFAULT NULL,
  `omit_insert_yn` char(1) DEFAULT NULL,
  `additional_unique_index_yn` char(1) DEFAULT NULL,
  `additional_index_yn` char(1) DEFAULT NULL,
  `lookup_required_yn` char(1) DEFAULT NULL,
  `insert_required_yn` char(1) DEFAULT NULL,
  `omit_update_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `folder_attribute` (`folder`,`attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_attribute`
--

LOCK TABLES `folder_attribute` WRITE;
/*!40000 ALTER TABLE `folder_attribute` DISABLE KEYS */;
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('permissions','permission',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_folder','permission',3,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('date_formats','date_format',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','exclude_application_export_yn',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','attribute',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','attribute',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','prompt',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','prompt',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','attribute_datatype',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute_datatype','attribute_datatype',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','distill_directory',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','command_line',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','float_decimal_places',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','display_order',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','process_set',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','post_change_javascript',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','preprompt_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','preprompt_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt','drop_down_prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt_data','drop_down_prompt',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','populate_drop_down_process',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','populate_drop_down_process',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt_data','drop_down_prompt_data',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','application',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','drop_down_prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','drop_down_prompt',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_folder','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_operation','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role','folder_count_yn',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','pair_1tom_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','form',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('form','form',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','prepend_http_protocol_yn',NULL,15,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','hint_message',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt','hint_message',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('prompt','hint_message',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('prompt','input_width',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','insert_rows_number',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_user','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_appaserver_user','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','login_name',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','ajax_fill_drop_down_yn',0,8,'n','n',NULL,NULL,NULL,NULL,'n');
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','lookup_email_output_yn',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','next_session_number',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('null','null',0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','index_directory',0,16,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('operation','operation',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_operation','operation',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('operation','output_yn',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('prompt','upload_filename_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_user','password',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','populate_drop_down_process',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','primary_key_index',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','process',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','display_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_process','process',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_process_set_member','process',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','process_set',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','display_order',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_process_set_member','process_set',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','attribute',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','attribute',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('prompt','prompt',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','related_attribute',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','related_folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_folder','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_operation','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_appaserver_user','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_process','role',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role_process_set_member','role',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','appaserver_session',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','appaserver_yn',NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','width',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','application_title',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_user','person_full_name',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','relative_source_directory',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','next_reference_number',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','background_color',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','post_change_javascript',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute_exclude','attribute',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','omit_1tom_detail_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','relation_type_isa_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','prompt_mto1_recursive_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute_exclude','role',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('grace_output','grace_output',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','grace_output',NULL,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_row_level_restrictions','row_level_restriction',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_datatype_folder','datatype_aggregation_sum_yn',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','grace_execution_directory',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_row_level_restrictions','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','preprompt_help_text',0,8,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute_exclude','permission',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','omit_insert_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','ghost_script_directory',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt_data','display_order',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('drop_down_prompt','optional_display',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','notepad',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','notepad',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','notepad',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','last_access_date',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','last_access_time',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','grace_home_directory',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','grace_free_option_yn',NULL,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','prompt_display_text',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','prompt_display_bottom_yn',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','chart_email_command_line',NULL,16,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','html_help_file_anchor',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','html_help_file_anchor',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','html_help_file_anchor',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','post_change_process',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','insert_required_yn',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','value_folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','copy_common_attributes_yn',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','additional_unique_index_yn',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','additional_index_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','ssl_support_yn',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','max_drop_down_size',NULL,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','execution_count',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','automatic_preselection_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('role','override_row_restrictions_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('row_level_restrictions','row_level_restriction',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','omit_insert_prompt_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','post_change_javascript',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','post_change_javascript',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','drop_down_multi_select_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','drop_down_multi_select_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','lookup_time_chart_output_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','lookup_histogram_output_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','database_date_format',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','user_date_format',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_user','user_date_format',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('prompt','date_yn',NULL,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','on_focus_javascript_function',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','lookup_required_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','datatype_folder',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','foreign_folder',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','date_attribute',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','process_generic_unit',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','http_user_agent',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_units','process_generic_unit',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','preprompt_help_text',0,8,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_datatype_folder','datatype_folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_datatype_folder','datatype_bar_graph_yn',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_datatype_folder','datatype_scale_graph_zero_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','process_set_display',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_output','process_set',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_output','process',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','remote_ip_address',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','login_date',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('appaserver_sessions','login_time',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('attribute','appaserver_yn',NULL,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','appaserver_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','max_query_rows_for_drop_downs',NULL,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application_constants','application_constant',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application_constants','application_constant_value',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','hint_message',0,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','drop_down_multi_select_yn',0,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','time_attribute',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','lookup_before_drop_down_yn',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','join_1tom_each_row_yn',NULL,6,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_files','javascript_filename',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_folders','folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_folders','javascript_filename',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_processes','process',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_processes','javascript_filename',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_process_sets','process_set',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('javascript_process_sets','javascript_filename',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('relation','omit_lookup_before_drop_down_yn',0,9,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('subschemas','subschema',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_groups','process_group',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','subschema',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process','process_group',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set','process_group',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','frameset_menu_horizontal_yn',NULL,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('application','appaserver_version',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('upgrade_scripts','upgrade_script',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('upgrade_scripts','appaserver_version',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_output','value_folder',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_generic_value_folder','value_attribute',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_user_drop_down_attribute','drop_down_folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_user_drop_down_attribute','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_user_drop_down_attribute','folder',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_user_drop_down_attribute','prepend_yn',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_user_drop_down_attribute','attribute',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_drop_down_attribute','drop_down_folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_drop_down_attribute','attribute',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('additional_drop_down_attribute','folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','no_initial_capital_yn',NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_parameter','populate_helper_process',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('process_set_parameter','populate_helper_process',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('row_security_role_update','attribute_not_null',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('row_security_role_update','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder','data_directory',0,15,'n','n',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('login_default_role','login_name',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('login_default_role','role',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('folder_attribute','omit_update_yn',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('select_statement','login_name',2,NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('select_statement','select_statement',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('select_statement','select_statement_title',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('foreign_attribute','folder',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('foreign_attribute','foreign_attribute',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('foreign_attribute','foreign_key_index',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('foreign_attribute','related_attribute',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `folder_attribute` (`folder`, `attribute`, `primary_key_index`, `display_order`, `omit_insert_prompt_yn`, `omit_insert_yn`, `additional_unique_index_yn`, `additional_index_yn`, `lookup_required_yn`, `insert_required_yn`, `omit_update_yn`) VALUES ('foreign_attribute','related_folder',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `folder_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder_row_level_restrictions`
--

DROP TABLE IF EXISTS `folder_row_level_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `folder_row_level_restrictions` (
  `folder` char(35) NOT NULL,
  `row_level_restriction` char(30) DEFAULT NULL,
  UNIQUE KEY `folder_row_level_restrictions` (`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder_row_level_restrictions`
--

LOCK TABLES `folder_row_level_restrictions` WRITE;
/*!40000 ALTER TABLE `folder_row_level_restrictions` DISABLE KEYS */;
INSERT INTO `folder_row_level_restrictions` (`folder`, `row_level_restriction`) VALUES ('appaserver_user','row_level_non_owner_view_only');
/*!40000 ALTER TABLE `folder_row_level_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `foreign_attribute`
--

DROP TABLE IF EXISTS `foreign_attribute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `foreign_attribute` (
  `folder` char(35) NOT NULL,
  `related_folder` char(35) NOT NULL,
  `related_attribute` char(60) NOT NULL,
  `foreign_attribute` char(60) NOT NULL,
  `foreign_key_index` int(11) DEFAULT NULL,
  UNIQUE KEY `foreign_attribute` (`folder`,`related_folder`,`related_attribute`,`foreign_attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `foreign_attribute`
--

LOCK TABLES `foreign_attribute` WRITE;
/*!40000 ALTER TABLE `foreign_attribute` DISABLE KEYS */;
/*!40000 ALTER TABLE `foreign_attribute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form`
--

DROP TABLE IF EXISTS `form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form` (
  `form` char(6) NOT NULL,
  UNIQUE KEY `form` (`form`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form`
--

LOCK TABLES `form` WRITE;
/*!40000 ALTER TABLE `form` DISABLE KEYS */;
INSERT INTO `form` (`form`) VALUES ('prompt');
INSERT INTO `form` (`form`) VALUES ('table');
/*!40000 ALTER TABLE `form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `grace_output`
--

DROP TABLE IF EXISTS `grace_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `grace_output` (
  `grace_output` char(15) NOT NULL,
  UNIQUE KEY `grace_output` (`grace_output`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grace_output`
--

LOCK TABLES `grace_output` WRITE;
/*!40000 ALTER TABLE `grace_output` DISABLE KEYS */;
INSERT INTO `grace_output` (`grace_output`) VALUES ('direct_pdf');
INSERT INTO `grace_output` (`grace_output`) VALUES ('jpeg');
INSERT INTO `grace_output` (`grace_output`) VALUES ('postscript_pdf');
/*!40000 ALTER TABLE `grace_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `javascript_files`
--

DROP TABLE IF EXISTS `javascript_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `javascript_files` (
  `javascript_filename` char(80) NOT NULL,
  UNIQUE KEY `javascript_files` (`javascript_filename`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `javascript_files`
--

LOCK TABLES `javascript_files` WRITE;
/*!40000 ALTER TABLE `javascript_files` DISABLE KEYS */;
INSERT INTO `javascript_files` (`javascript_filename`) VALUES ('clone_folder.js');
INSERT INTO `javascript_files` (`javascript_filename`) VALUES ('post_change_attribute.js');
INSERT INTO `javascript_files` (`javascript_filename`) VALUES ('post_change_folder_attribute.js');
/*!40000 ALTER TABLE `javascript_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `javascript_folders`
--

DROP TABLE IF EXISTS `javascript_folders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `javascript_folders` (
  `javascript_filename` char(80) NOT NULL,
  `folder` char(35) NOT NULL,
  UNIQUE KEY `javascript_folders` (`javascript_filename`,`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `javascript_folders`
--

LOCK TABLES `javascript_folders` WRITE;
/*!40000 ALTER TABLE `javascript_folders` DISABLE KEYS */;
INSERT INTO `javascript_folders` (`javascript_filename`, `folder`) VALUES ('post_change_attribute.js','attribute');
INSERT INTO `javascript_folders` (`javascript_filename`, `folder`) VALUES ('post_change_folder_attribute.js','folder_attribute');
/*!40000 ALTER TABLE `javascript_folders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `javascript_process_sets`
--

DROP TABLE IF EXISTS `javascript_process_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `javascript_process_sets` (
  `javascript_filename` char(80) NOT NULL,
  `process_set` char(40) NOT NULL,
  UNIQUE KEY `javascript_process_sets` (`javascript_filename`,`process_set`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `javascript_process_sets`
--

LOCK TABLES `javascript_process_sets` WRITE;
/*!40000 ALTER TABLE `javascript_process_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `javascript_process_sets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `javascript_processes`
--

DROP TABLE IF EXISTS `javascript_processes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `javascript_processes` (
  `javascript_filename` char(80) NOT NULL,
  `process` char(40) NOT NULL,
  UNIQUE KEY `javascript_processes` (`javascript_filename`,`process`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `javascript_processes`
--

LOCK TABLES `javascript_processes` WRITE;
/*!40000 ALTER TABLE `javascript_processes` DISABLE KEYS */;
INSERT INTO `javascript_processes` (`javascript_filename`, `process`) VALUES ('clone_folder.js','clone_folder');
/*!40000 ALTER TABLE `javascript_processes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_default_role`
--

DROP TABLE IF EXISTS `login_default_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_default_role` (
  `login_name` char(50) NOT NULL,
  `role` char(25) DEFAULT NULL,
  UNIQUE KEY `login_default_role` (`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_default_role`
--

LOCK TABLES `login_default_role` WRITE;
/*!40000 ALTER TABLE `login_default_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_default_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation`
--

DROP TABLE IF EXISTS `operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation` (
  `operation` char(30) NOT NULL,
  `output_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `operation` (`operation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation`
--

LOCK TABLES `operation` WRITE;
/*!40000 ALTER TABLE `operation` DISABLE KEYS */;
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('delete','n');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('detail','y');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('delete_isa_only',NULL);
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('null','y');
INSERT INTO `operation` (`operation`, `output_yn`) VALUES ('google_map','y');
/*!40000 ALTER TABLE `operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `permission` char(10) NOT NULL,
  UNIQUE KEY `permissions` (`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`permission`) VALUES ('insert');
INSERT INTO `permissions` (`permission`) VALUES ('lookup');
INSERT INTO `permissions` (`permission`) VALUES ('update');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process`
--

DROP TABLE IF EXISTS `process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process` (
  `process` char(40) NOT NULL,
  `command_line` text,
  `notepad` text,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `execution_count` int(11) DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `process_group` char(20) DEFAULT NULL,
  `process_set_display` char(40) DEFAULT NULL,
  `appaserver_yn` char(1) DEFAULT NULL,
  `preprompt_help_text` text,
  UNIQUE KEY `process` (`process`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process`
--

LOCK TABLES `process` WRITE;
/*!40000 ALTER TABLE `process` DISABLE KEYS */;
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('add_column','add_column ignored $session $login_name $role folder attribute really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('alter_column_datatype','alter_column_datatype ignored $session $login_name $role folder attribute really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('clone_folder','clone_folder ignored n $session $login_name $role destination_application folder attribute old_data new_data html delete_yn execute_yn database_management_system output2file_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('create_application','create_application ignored build_shell_script_yn $session $login_name $role destination_application system_folders_yn n really_yn database_management_system',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('create_table','create_table ignored n $session $login_name $role destination_application folder really_yn database_management_system',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('detail','detail ignored $session $login_name $folder $role $target_frame $primary_data_list $dictionary',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('drop_column','drop_column ignored $session $login_name $role folder attribute really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('rename_table','rename_table ignored $session $login_name $role old_folder new_folder really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('view_documentation','view_diagrams ignored',NULL,NULL,NULL,NULL,'documentation',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('view_source','view_source $application $session $login_name $role',NULL,NULL,1,NULL,'documentation',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('rename_column','rename_column ignored $process old_attribute folder attribute really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('export_folder','clone_folder ignored n $session $login_name $role destination_application folder attribute old_data new_data html n really_yn database_management_system y export_output',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('table_rectification','table_rectification ignored $session $login $role','This process compares the Appaserver attributes with the Mysql table columns. It then gives you the opportunity to drop the residual columns.',NULL,4,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('export_process','export_process ignored $session $login_name $role $process $dictionary','For a list of processes, this process exports from the following: process, role_process, process_parameter, javascript_libraries, prompt, drop_down_prompt, and drop_down_prompt_data.',NULL,12,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('export_subschema','export_subschema ignored $session $login_name $role filller $dictionary','This process exports for a list of folders from the following: folder, relation, folder_attribute, attribute,  role_operation, and role_folder.',NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('generic_load','generic_load ignored $session $role $process',NULL,NULL,NULL,NULL,'load',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('fix_orphans','fix_orphans ignored $process orphans_folder delete_yn really_yn','This process traverses the many-to-one relationships for a folder. It inserts the missing primary keys that contain foreign keys in the selected folder. Warning: this process could take a long time to run.',NULL,187,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('export_process_set','export_process_set ignored $session $login_name $role $process $dictionary','For a list of process sets, this process exports from the following: process_set, process_set_parameter, javascript_libraries, role_process_set, prompt, drop_down_prompt, and drop_down_prompt_data.',NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('delete','delete_folder_row ignored $session $person $folder $role $primary_data_list \'\' n',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('delete_isa_only','delete_folder_row ignored $session $person $folder $role $primary_data_list \'\' y',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('appaserver_info','appaserver_info.sh ignored $login_name',NULL,NULL,NULL,NULL,'documentation',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('orphans_process_folder_list','orphans_process_folder_list.sh ignored',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('export_application','clone_application ignored $session $login_name $role destination_application delete_yn system_folders_yn really_yn output2file_yn database_management_system export_output',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('attribute_list','attribute_list ignored $dictionary',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('change_password','maintain_user_account ignored $session $person $role',NULL,NULL,2,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('create_empty_application','create_empty_application ignored $session $login_name $role $process destination_application new_application_title y delete_application_yn execute_yn','This process creates an empty application. It creates a new database, the Appaserver tables, the data directories, among other application objects. Following this process, you can begin inserting the folder rows.',NULL,224,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('google_map','google_map_operation ignored $process $login_name $role $folder latitude longitude utm_easting utm_northing $process_id $process_row_count $session $dictionary',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('grant_select_to_user','grant_select_to_user ignored $process login_name connect_from_host revoke_only_yn really_yn',NULL,NULL,NULL,NULL,NULL,NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('view_appaserver_log_file','view_appaserver_error_file.sh ignored /var/log/appaserver line_count','Most error messages are logged to this file. If you get the Server Error screen, then this file is the first place to find a clue. <big> <bold>Warning:</bold></big> this process exposes the session number assigned to each user\'s login.',NULL,NULL,NULL,'output',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('execute_select_statement','execute_select_statement ignored $process $login_name $session $role output_medium filename select_statement_title login_name',NULL,NULL,NULL,NULL,'output',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('upload_source_file','upload_source_file ignored $process filename','This process allows you to upload non-executable source files, like javascript. The destination directory is $APPASERVER_HOME/src_$application. However, it may not exist. To have it created, visit <a href=https://appahost.com/contact target=_new>https://appahost.com/contact</a>.',NULL,NULL,NULL,'load',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('merge_purge','merge_purge ignored $session $role $process',NULL,NULL,NULL,NULL,'manipulate',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('report_writer','post_report_writer $application $session $login_name $role $process folder one',NULL,NULL,NULL,NULL,'output',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('import_predictivebooks','import_predictivebooks_process.sh ignored $process module execute_yn','This process imports the PredictiveBooks application.',NULL,NULL,NULL,'manipulate',NULL,'y',NULL);
INSERT INTO `process` (`process`, `command_line`, `notepad`, `html_help_file_anchor`, `execution_count`, `post_change_javascript`, `process_group`, `process_set_display`, `appaserver_yn`, `preprompt_help_text`) VALUES ('graphviz_database_schema','graphviz_database_schema_process.sh $process appaserver_yn',NULL,NULL,NULL,NULL,'documentation',NULL,NULL,NULL);
/*!40000 ALTER TABLE `process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic_datatype_folder`
--

DROP TABLE IF EXISTS `process_generic_datatype_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_generic_datatype_folder` (
  `datatype_folder` char(50) NOT NULL,
  `datatype_aggregation_sum_yn` char(1) DEFAULT NULL,
  `datatype_bar_graph_yn` char(1) DEFAULT NULL,
  `datatype_scale_graph_zero_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `process_generic_datatype_folder` (`datatype_folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic_datatype_folder`
--

LOCK TABLES `process_generic_datatype_folder` WRITE;
/*!40000 ALTER TABLE `process_generic_datatype_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_generic_datatype_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic_output`
--

DROP TABLE IF EXISTS `process_generic_output`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_generic_output` (
  `process` char(40) NOT NULL,
  `process_set` char(40) NOT NULL,
  `value_folder` char(50) NOT NULL,
  UNIQUE KEY `process_generic_output` (`process`,`process_set`,`value_folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic_output`
--

LOCK TABLES `process_generic_output` WRITE;
/*!40000 ALTER TABLE `process_generic_output` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_generic_output` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic_units`
--

DROP TABLE IF EXISTS `process_generic_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_generic_units` (
  `process_generic_unit` char(15) NOT NULL,
  UNIQUE KEY `process_generic_units` (`process_generic_unit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic_units`
--

LOCK TABLES `process_generic_units` WRITE;
/*!40000 ALTER TABLE `process_generic_units` DISABLE KEYS */;
INSERT INTO `process_generic_units` (`process_generic_unit`) VALUES ('datatype_folder');
INSERT INTO `process_generic_units` (`process_generic_unit`) VALUES ('value_folder');
/*!40000 ALTER TABLE `process_generic_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_generic_value_folder`
--

DROP TABLE IF EXISTS `process_generic_value_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_generic_value_folder` (
  `value_folder` char(50) NOT NULL,
  `date_attribute` char(60) DEFAULT NULL,
  `time_attribute` char(60) DEFAULT NULL,
  `value_attribute` char(60) DEFAULT NULL,
  `datatype_folder` char(50) DEFAULT NULL,
  `process_generic_unit` char(15) DEFAULT NULL,
  `foreign_folder` char(50) DEFAULT NULL,
  UNIQUE KEY `process_generic_value_folder` (`value_folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_generic_value_folder`
--

LOCK TABLES `process_generic_value_folder` WRITE;
/*!40000 ALTER TABLE `process_generic_value_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_generic_value_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_groups`
--

DROP TABLE IF EXISTS `process_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_groups` (
  `process_group` char(20) NOT NULL,
  UNIQUE KEY `process_groups` (`process_group`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_groups`
--

LOCK TABLES `process_groups` WRITE;
/*!40000 ALTER TABLE `process_groups` DISABLE KEYS */;
INSERT INTO `process_groups` (`process_group`) VALUES ('documentation');
INSERT INTO `process_groups` (`process_group`) VALUES ('load');
INSERT INTO `process_groups` (`process_group`) VALUES ('manipulate');
INSERT INTO `process_groups` (`process_group`) VALUES ('output');
/*!40000 ALTER TABLE `process_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_parameter`
--

DROP TABLE IF EXISTS `process_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_parameter` (
  `process` char(40) NOT NULL,
  `folder` char(35) NOT NULL,
  `attribute` char(60) NOT NULL,
  `prompt` char(50) NOT NULL,
  `drop_down_prompt` char(50) NOT NULL,
  `display_order` int(11) DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `preprompt_yn` char(1) DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `populate_helper_process` char(40) DEFAULT NULL,
  UNIQUE KEY `process_parameter` (`process`,`folder`,`attribute`,`prompt`,`drop_down_prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_parameter`
--

LOCK TABLES `process_parameter` WRITE;
/*!40000 ALTER TABLE `process_parameter` DISABLE KEYS */;
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','folder_attribute','null','null','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','system_folders_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_table','null','null','execute_yn','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','null','null','output2file_yn','null',6,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','folder','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','folder','null','new_folder','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','folder_attribute','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','null','null','old_data','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','folder_attribute','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','null','null','execute_yn','null',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','null','null','execute_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','null','null','new_data','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','attribute','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','folder_attribute','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','null','null','old_folder','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process','null','null','exclude_roles_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','null','null','old_attribute','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('clone_folder','null','null','delete_yn','null',7,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process_set','null','null','exclude_roles_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_subschema','folder','null','null','null',2,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_column','attribute','null','null','null',NULL,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','null','null','attribute','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('drop_column','null','null','execute_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictivebooks','null','null','null','predictivebooks_module',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process','process','null','null','null',1,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','null','null','execute_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('rename_table','null','null','execute_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','execute_yn','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_table','folder','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_application','null','null','null','export_application_export_output',4,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_folder','folder','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('execute_select_statement','select_statement','null','null','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_folder','null','null','null','export_output',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_process_set','process_set','null','null','null',1,'y',NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('fix_orphans','null','null','orphans_folder','null',1,NULL,NULL,'orphans_process_folder_list',NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('fix_orphans','null','null','delete_yn','null',5,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('add_column','attribute','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('alter_column_datatype','attribute','null','null','null',1,NULL,'y',NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('export_application','null','null','system_folders_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_application','null','null','build_shell_script_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','new_application_title','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('upload_source_file','null','null','filename','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','destination_application','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('create_empty_application','null','null','delete_application_yn','null',7,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('execute_select_statement','null','null','null','execute_select_statement_output_medium',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('execute_select_statement','null','null','filename','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','execute_yn','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','connect_from_host','null',3,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','appaserver_user','null','null','null',1,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('view_appaserver_log_file','null','null','line_count','null',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('fix_orphans','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('grant_select_to_user','null','null','revoke_only_yn','null',2,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('import_predictivebooks','null','null','execute_yn','null',9,NULL,NULL,NULL,NULL);
INSERT INTO `process_parameter` (`process`, `folder`, `attribute`, `prompt`, `drop_down_prompt`, `display_order`, `drop_down_multi_select_yn`, `preprompt_yn`, `populate_drop_down_process`, `populate_helper_process`) VALUES ('graphviz_database_schema','null','null','appaserver_yn','null',1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `process_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_set`
--

DROP TABLE IF EXISTS `process_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_set` (
  `process_set` char(40) NOT NULL,
  `notepad` text,
  `html_help_file_anchor` char(50) DEFAULT NULL,
  `post_change_javascript` char(50) DEFAULT NULL,
  `prompt_display_text` char(25) DEFAULT NULL,
  `prompt_display_bottom_yn` char(1) DEFAULT NULL,
  `process_group` char(20) DEFAULT NULL,
  `preprompt_help_text` text,
  UNIQUE KEY `process_set` (`process_set`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_set`
--

LOCK TABLES `process_set` WRITE;
/*!40000 ALTER TABLE `process_set` DISABLE KEYS */;
INSERT INTO `process_set` (`process_set`, `notepad`, `html_help_file_anchor`, `post_change_javascript`, `prompt_display_text`, `prompt_display_bottom_yn`, `process_group`, `preprompt_help_text`) VALUES ('null',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `process_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `process_set_parameter`
--

DROP TABLE IF EXISTS `process_set_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `process_set_parameter` (
  `process_set` char(40) NOT NULL,
  `folder` char(35) NOT NULL,
  `attribute` char(60) NOT NULL,
  `prompt` char(50) NOT NULL,
  `drop_down_prompt` char(50) NOT NULL,
  `display_order` int(11) DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `preprompt_yn` char(1) DEFAULT NULL,
  `populate_drop_down_process` char(40) DEFAULT NULL,
  `populate_helper_process` char(40) DEFAULT NULL,
  UNIQUE KEY `process_set_parameter` (`process_set`,`folder`,`attribute`,`prompt`,`drop_down_prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `process_set_parameter`
--

LOCK TABLES `process_set_parameter` WRITE;
/*!40000 ALTER TABLE `process_set_parameter` DISABLE KEYS */;
/*!40000 ALTER TABLE `process_set_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prompt`
--

DROP TABLE IF EXISTS `prompt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prompt` (
  `prompt` char(50) NOT NULL,
  `hint_message` text,
  `upload_filename_yn` char(1) DEFAULT NULL,
  `date_yn` char(1) DEFAULT NULL,
  `input_width` int(11) DEFAULT NULL,
  UNIQUE KEY `prompt` (`prompt`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prompt`
--

LOCK TABLES `prompt` WRITE;
/*!40000 ALTER TABLE `prompt` DISABLE KEYS */;
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('begin_date',NULL,NULL,'y',10);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('begin_time','Format HHMM',NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('chart_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('delete_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('destination_application',NULL,NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('destination_directory',NULL,NULL,NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('output2file_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('email_address','Optionally email the results',NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('end_date',NULL,NULL,'y',10);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('end_time','Format HHMM',NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('exclude_folder_comma_list',NULL,NULL,NULL,255);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('filename',NULL,'y',NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('build_shell_script_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_data',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_folder',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('null',NULL,NULL,NULL,0);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('offset',NULL,NULL,NULL,5);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_data',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_folder',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('output_filename','Optional',NULL,NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('execute_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('source_directory',NULL,NULL,NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('system_folders_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('where_clause',NULL,NULL,NULL,100);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('notes',NULL,NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('old_attribute',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_attribute',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('optional_folder',NULL,NULL,NULL,NULL);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('orphans_folder',NULL,NULL,NULL,NULL);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('attribute',NULL,NULL,NULL,50);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('days_to_average','Defaults to 30',NULL,NULL,3);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('display_count_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('begin_year',NULL,NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('end_year',NULL,NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('detail_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('exclude_roles_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('dynamic_ending_date',NULL,NULL,'y',10);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('create_database_yn','Should the application be stored in a new database or the current database?',NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('new_application_title',NULL,NULL,NULL,30);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('delete_application_yn','Delete the existing application?',NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('revoke_only_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('line_count','How many lines from the end to include? Defaults to 50.',NULL,NULL,4);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('really_yn',NULL,NULL,NULL,1);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('connect_from_host',NULL,NULL,NULL,60);
INSERT INTO `prompt` (`prompt`, `hint_message`, `upload_filename_yn`, `date_yn`, `input_width`) VALUES ('appaserver_yn',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `prompt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relation` (
  `folder` char(35) NOT NULL,
  `related_folder` char(35) NOT NULL,
  `related_attribute` char(60) NOT NULL,
  `pair_1tom_order` int(11) DEFAULT NULL,
  `omit_1tom_detail_yn` char(1) DEFAULT NULL,
  `prompt_mto1_recursive_yn` char(1) DEFAULT NULL,
  `relation_type_isa_yn` char(1) DEFAULT NULL,
  `copy_common_attributes_yn` char(1) DEFAULT NULL,
  `automatic_preselection_yn` char(1) DEFAULT NULL,
  `drop_down_multi_select_yn` char(1) DEFAULT NULL,
  `hint_message` text,
  `join_1tom_each_row_yn` char(1) DEFAULT NULL,
  `omit_lookup_before_drop_down_yn` char(1) DEFAULT NULL,
  `ajax_fill_drop_down_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `relation` (`folder`,`related_folder`,`related_attribute`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('application','grace_output','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('attribute','attribute_datatype','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('attribute_exclude','attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('attribute_exclude','permissions','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('attribute_exclude','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('drop_down_prompt_data','drop_down_prompt','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder','form','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder','process','post_change_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder_attribute','attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder_attribute','folder','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_operation','operation','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder_row_level_restrictions','folder','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder_row_level_restrictions','row_level_restrictions','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('operation','process','operation',NULL,NULL,NULL,'y',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','populate_helper_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','folder','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','folder','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process','populate_helper_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','process','populate_drop_down_process',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('relation','attribute','related_attribute',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('relation','folder','null',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('relation','folder','related_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_appaserver_user','appaserver_user','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_appaserver_user','role','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_folder','folder','null',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_folder','permissions','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_folder','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_operation','folder','null',4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_operation','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_process','process','null',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_process','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','attribute','value_attribute',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','process','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','role','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('role_process_set_member','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_folders','javascript_files','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('application','date_formats','database_date_format',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('application','date_formats','user_date_format',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('appaserver_user','date_formats','user_date_format',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_datatype_folder','folder','datatype_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_output','process','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_output','process_generic_value_folder','value_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','attribute','time_attribute',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('appaserver_sessions','appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','process','null',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','folder','foreign_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','process_generic_datatype_folder','datatype_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_output','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','attribute','date_attribute',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','process_generic_units','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_folders','folder','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_processes','javascript_files','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_processes','process','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_process_sets','javascript_files','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('javascript_process_sets','process_set','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('folder','subschemas','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process','process_groups','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set','process_groups','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_generic_value_folder','folder','value_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('additional_user_drop_down_attribute','folder_attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('additional_user_drop_down_attribute','folder','drop_down_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('additional_user_drop_down_attribute','appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('additional_drop_down_attribute','folder_attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('additional_drop_down_attribute','folder','drop_down_folder',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','drop_down_prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_set_parameter','drop_down_prompt','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('process_parameter','attribute','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('row_security_role_update','folder_attribute','attribute_not_null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('login_default_role','role_appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('select_statement','appaserver_user','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('foreign_attribute','relation','null',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `relation` (`folder`, `related_folder`, `related_attribute`, `pair_1tom_order`, `omit_1tom_detail_yn`, `prompt_mto1_recursive_yn`, `relation_type_isa_yn`, `copy_common_attributes_yn`, `automatic_preselection_yn`, `drop_down_multi_select_yn`, `hint_message`, `join_1tom_each_row_yn`, `omit_lookup_before_drop_down_yn`, `ajax_fill_drop_down_yn`) VALUES ('foreign_attribute','folder_attribute','foreign_attribute',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role` char(25) NOT NULL,
  `folder_count_yn` char(1) DEFAULT NULL,
  `override_row_restrictions_yn` char(1) DEFAULT NULL,
  UNIQUE KEY `role` (`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`role`, `folder_count_yn`, `override_row_restrictions_yn`) VALUES ('system','y','y');
INSERT INTO `role` (`role`, `folder_count_yn`, `override_row_restrictions_yn`) VALUES ('supervisor','y','y');
INSERT INTO `role` (`role`, `folder_count_yn`, `override_row_restrictions_yn`) VALUES ('dataentry','n',NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_appaserver_user`
--

DROP TABLE IF EXISTS `role_appaserver_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_appaserver_user` (
  `role` char(25) NOT NULL,
  `login_name` char(50) NOT NULL,
  UNIQUE KEY `role_appaserver_user` (`role`,`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_appaserver_user`
--

LOCK TABLES `role_appaserver_user` WRITE;
/*!40000 ALTER TABLE `role_appaserver_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_appaserver_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_folder`
--

DROP TABLE IF EXISTS `role_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_folder` (
  `folder` char(35) NOT NULL,
  `role` char(25) NOT NULL,
  `permission` char(10) NOT NULL,
  UNIQUE KEY `role_folder` (`folder`,`role`,`permission`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_folder`
--

LOCK TABLES `role_folder` WRITE;
/*!40000 ALTER TABLE `role_folder` DISABLE KEYS */;
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('additional_drop_down_attribute','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('additional_drop_down_attribute','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('additional_user_drop_down_attribute','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('additional_user_drop_down_attribute','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('appaserver_sessions','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('appaserver_sessions','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('appaserver_user','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('appaserver_user','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application_constants','supervisor','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application_constants','supervisor','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application_constants','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('application_constants','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute_datatype','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute_datatype','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute_exclude','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('attribute_exclude','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('date_formats','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('date_formats','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('drop_down_prompt','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('drop_down_prompt','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('drop_down_prompt_data','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('drop_down_prompt_data','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder_attribute','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder_attribute','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder_row_level_restrictions','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('folder_row_level_restrictions','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('foreign_attribute','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('foreign_attribute','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('form','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('form','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('grace_output','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('grace_output','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_files','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_files','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_folders','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_folders','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_processes','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_processes','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_process_sets','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('javascript_process_sets','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('login_default_role','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('login_default_role','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('operation','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('operation','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('permissions','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('permissions','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_datatype_folder','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_datatype_folder','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_output','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_output','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_units','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_units','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_value_folder','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_generic_value_folder','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_groups','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_groups','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_parameter','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_parameter','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_set','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_set','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_set_parameter','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('process_set_parameter','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('prompt','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('prompt','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('relation','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('relation','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_appaserver_user','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_appaserver_user','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_folder','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_folder','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_operation','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_operation','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_process','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_process','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_process_set_member','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('role_process_set_member','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('row_level_restrictions','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('row_level_restrictions','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('row_security_role_update','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('row_security_role_update','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','dataentry','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','dataentry','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','supervisor','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','supervisor','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('select_statement','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('subschemas','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('subschemas','system','update');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('upgrade_scripts','system','insert');
INSERT INTO `role_folder` (`folder`, `role`, `permission`) VALUES ('upgrade_scripts','system','update');
/*!40000 ALTER TABLE `role_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_operation`
--

DROP TABLE IF EXISTS `role_operation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_operation` (
  `folder` char(35) NOT NULL,
  `role` char(25) NOT NULL,
  `operation` char(30) NOT NULL,
  UNIQUE KEY `role_operation` (`folder`,`role`,`operation`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_operation`
--

LOCK TABLES `role_operation` WRITE;
/*!40000 ALTER TABLE `role_operation` DISABLE KEYS */;
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('additional_drop_down_attribute','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('additional_drop_down_attribute','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('additional_user_drop_down_attribute','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('additional_user_drop_down_attribute','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('appaserver_sessions','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('appaserver_sessions','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('appaserver_user','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('appaserver_user','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('application','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('application_constants','supervisor','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('application_constants','supervisor','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('application_constants','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('attribute','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('attribute','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('attribute_exclude','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('date_formats','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('date_formats','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('drop_down_prompt','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('drop_down_prompt','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('drop_down_prompt_data','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('drop_down_prompt_data','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder_attribute','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder_attribute','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder_row_level_restrictions','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('folder_row_level_restrictions','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('foreign_attribute','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('foreign_attribute','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('form','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_files','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_files','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_folders','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_folders','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_processes','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_processes','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_process_sets','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('javascript_process_sets','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('login_default_role','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('login_default_role','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('operation','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('operation','system','delete_isa_only');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('permissions','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_datatype_folder','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_datatype_folder','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_output','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_output','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_units','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_units','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_value_folder','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_generic_value_folder','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_groups','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_groups','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_parameter','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_parameter','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_set','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_set','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_set_parameter','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('process_set_parameter','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('prompt','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('prompt','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('relation','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('relation','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_appaserver_user','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_folder','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_operation','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_process','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_process_set_member','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('role_process_set_member','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('row_level_restrictions','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('row_security_role_update','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('row_security_role_update','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('select_statement','supervisor','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('subschemas','system','delete');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('subschemas','system','detail');
INSERT INTO `role_operation` (`folder`, `role`, `operation`) VALUES ('upgrade_scripts','system','delete');
/*!40000 ALTER TABLE `role_operation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_process`
--

DROP TABLE IF EXISTS `role_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_process` (
  `role` char(25) NOT NULL,
  `process` char(40) NOT NULL,
  UNIQUE KEY `role_process` (`role`,`process`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_process`
--

LOCK TABLES `role_process` WRITE;
/*!40000 ALTER TABLE `role_process` DISABLE KEYS */;
INSERT INTO `role_process` (`role`, `process`) VALUES ('dataentry','appaserver_info');
INSERT INTO `role_process` (`role`, `process`) VALUES ('dataentry','change_password');
INSERT INTO `role_process` (`role`, `process`) VALUES ('dataentry','execute_select_statement');
INSERT INTO `role_process` (`role`, `process`) VALUES ('dataentry','view_documentation');
INSERT INTO `role_process` (`role`, `process`) VALUES ('dataentry','view_source');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','appaserver_info');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','change_password');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','execute_select_statement');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','generic_load');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','graphviz_database_schema');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','merge_purge');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','report_writer');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','view_documentation');
INSERT INTO `role_process` (`role`, `process`) VALUES ('supervisor','view_source');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','add_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','alter_column_datatype');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','appaserver_info');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','change_password');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','clone_folder');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_empty_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','create_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','drop_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_application');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_folder');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_process');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_process_set');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','export_subschema');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','fix_orphans');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','generic_load');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','grant_select_to_user');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','graphviz_database_schema');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','import_predictivebooks');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','merge_purge');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','rename_column');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','rename_table');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','report_writer');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','table_rectification');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','upload_source_file');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_appaserver_log_file');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_documentation');
INSERT INTO `role_process` (`role`, `process`) VALUES ('system','view_source');
/*!40000 ALTER TABLE `role_process` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_process_set_member`
--

DROP TABLE IF EXISTS `role_process_set_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_process_set_member` (
  `process` char(40) NOT NULL,
  `process_set` char(40) NOT NULL,
  `role` char(25) NOT NULL,
  UNIQUE KEY `role_process_set_member` (`process`,`process_set`,`role`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_process_set_member`
--

LOCK TABLES `role_process_set_member` WRITE;
/*!40000 ALTER TABLE `role_process_set_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_process_set_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `row_level_restrictions`
--

DROP TABLE IF EXISTS `row_level_restrictions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `row_level_restrictions` (
  `row_level_restriction` char(30) NOT NULL,
  UNIQUE KEY `row_level_restrictions` (`row_level_restriction`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `row_level_restrictions`
--

LOCK TABLES `row_level_restrictions` WRITE;
/*!40000 ALTER TABLE `row_level_restrictions` DISABLE KEYS */;
INSERT INTO `row_level_restrictions` (`row_level_restriction`) VALUES ('row_level_non_owner_forbid');
INSERT INTO `row_level_restrictions` (`row_level_restriction`) VALUES ('row_level_non_owner_view_only');
/*!40000 ALTER TABLE `row_level_restrictions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `row_security_role_update`
--

DROP TABLE IF EXISTS `row_security_role_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `row_security_role_update` (
  `folder` char(35) NOT NULL,
  `attribute_not_null` char(50) DEFAULT NULL,
  UNIQUE KEY `row_security_role_update` (`folder`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `row_security_role_update`
--

LOCK TABLES `row_security_role_update` WRITE;
/*!40000 ALTER TABLE `row_security_role_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `row_security_role_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `select_statement`
--

DROP TABLE IF EXISTS `select_statement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `select_statement` (
  `select_statement_title` char(80) NOT NULL,
  `login_name` char(50) NOT NULL,
  `select_statement` text,
  UNIQUE KEY `select_statement` (`select_statement_title`,`login_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `select_statement`
--

LOCK TABLES `select_statement` WRITE;
/*!40000 ALTER TABLE `select_statement` DISABLE KEYS */;
/*!40000 ALTER TABLE `select_statement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subschemas`
--

DROP TABLE IF EXISTS `subschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subschemas` (
  `subschema` char(30) NOT NULL,
  UNIQUE KEY `subschemas` (`subschema`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subschemas`
--

LOCK TABLES `subschemas` WRITE;
/*!40000 ALTER TABLE `subschemas` DISABLE KEYS */;
INSERT INTO `subschemas` (`subschema`) VALUES ('activity');
INSERT INTO `subschemas` (`subschema`) VALUES ('application');
INSERT INTO `subschemas` (`subschema`) VALUES ('folder');
INSERT INTO `subschemas` (`subschema`) VALUES ('javascript');
INSERT INTO `subschemas` (`subschema`) VALUES ('operation');
INSERT INTO `subschemas` (`subschema`) VALUES ('process');
INSERT INTO `subschemas` (`subschema`) VALUES ('process_generic_output');
INSERT INTO `subschemas` (`subschema`) VALUES ('process_set');
INSERT INTO `subschemas` (`subschema`) VALUES ('security');
INSERT INTO `subschemas` (`subschema`) VALUES ('static');
/*!40000 ALTER TABLE `subschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_application`
--

DROP TABLE IF EXISTS `template_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_application` (
  `application` char(30) NOT NULL,
  `application_title` char(30) DEFAULT NULL,
  `database_date_format` char(15) DEFAULT NULL,
  `user_date_format` char(15) DEFAULT NULL,
  `appaserver_version` char(10) DEFAULT NULL,
  `relative_source_directory` char(50) DEFAULT NULL,
  `next_session_number` int(11) DEFAULT NULL,
  `next_reference_number` int(11) DEFAULT NULL,
  `background_color` char(7) DEFAULT NULL,
  `ghost_script_directory` char(50) DEFAULT NULL,
  `frameset_menu_horizontal_yn` char(1) DEFAULT NULL,
  `distill_directory` char(50) DEFAULT NULL,
  `grace_home_directory` char(50) DEFAULT NULL,
  `grace_execution_directory` char(50) DEFAULT NULL,
  `grace_free_option_yn` char(1) DEFAULT NULL,
  `grace_output` char(15) DEFAULT NULL,
  `max_drop_down_size` int(11) DEFAULT NULL,
  `ssl_support_yn` char(1) DEFAULT NULL,
  `max_query_rows_for_drop_downs` int(11) DEFAULT NULL,
  `prepend_http_protocol_yn` char(1) DEFAULT NULL,
  `chart_email_command_line` char(255) DEFAULT NULL,
  UNIQUE KEY `template_application` (`application`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_application`
--

LOCK TABLES `template_application` WRITE;
/*!40000 ALTER TABLE `template_application` DISABLE KEYS */;
INSERT INTO `template_application` (`application`, `application_title`, `database_date_format`, `user_date_format`, `appaserver_version`, `relative_source_directory`, `next_session_number`, `next_reference_number`, `background_color`, `ghost_script_directory`, `frameset_menu_horizontal_yn`, `distill_directory`, `grace_home_directory`, `grace_execution_directory`, `grace_free_option_yn`, `grace_output`, `max_drop_down_size`, `ssl_support_yn`, `max_query_rows_for_drop_downs`, `prepend_http_protocol_yn`, `chart_email_command_line`) VALUES ('template','Template Application','international','american','6.31','src_template:src_predictive',701,91,'#effdff',NULL,'y',NULL,'/usr/share/grace','/usr/bin',NULL,'postscript_pdf',200,'y',50,'y','mutt -s \'Here is your chart\' -a {filename} {}');
/*!40000 ALTER TABLE `template_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upgrade_scripts`
--

DROP TABLE IF EXISTS `upgrade_scripts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `upgrade_scripts` (
  `appaserver_version` char(10) NOT NULL,
  `upgrade_script` char(80) NOT NULL,
  UNIQUE KEY `upgrade_scripts` (`appaserver_version`,`upgrade_script`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upgrade_scripts`
--

LOCK TABLES `upgrade_scripts` WRITE;
/*!40000 ALTER TABLE `upgrade_scripts` DISABLE KEYS */;
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','add_column_ajax_fill_drop_down.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','create_folder_foreign_attribute.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','create_investment_subschema.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','create_investment_tables.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','create_subsidiary_transaction.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','creel_additional_species_report.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_add_column_calibrated_yn.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_add_column_set_negative_values_to_zero_yn.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_exo_load_heading.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_load_satlink3_file.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_output_measurement_googlecharts.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_process_load_EXO_data.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','hydrology_ysi_load_heading.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_folder_foreign_attribute.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_investment_subschema.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_process_post_change_account_balance.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_subschema_activity.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_subsidiary_transaction_subschema.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_waterquality_FIU_load.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','insert_waterquality_generic_googlechart.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','new_process_site_visit_sparrow_observations.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_creel_species_preferred_caught.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_depreciate_fixed_assets.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_grant_select_to_user.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_hydrology_output_annual_comparison.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_hydrology_station_datatype_list.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_process_clone_folder.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','reinsert_waterquality_output_merged_datasets.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.30','rename_to_foreign_key_index.sh');
INSERT INTO `upgrade_scripts` (`appaserver_version`, `upgrade_script`) VALUES ('6.31','new_process_graphviz_database_schema.sh');
/*!40000 ALTER TABLE `upgrade_scripts` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-15  2:03:25
insert into appaserver_user( login_name, password ) values ( 'nobody', 'changeit' );
insert into role_appaserver_user( role, login_name ) values ( 'system', 'nobody' );
insert into role_appaserver_user( role, login_name ) values ( 'supervisor', 'nobody' );
insert into role_appaserver_user( role, login_name ) values ( 'dataentry', 'nobody' );
